﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIS.Framework.ActionResults.Base
{
    public interface IActionResult
    {
        string Invoke();
    }
}
